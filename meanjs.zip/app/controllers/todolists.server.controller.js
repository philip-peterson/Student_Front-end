'use strict';

/**
 * Module dependencies.
 */
var mongoose = require('mongoose'),
	errorHandler = require('./errors'),
	Todolist = mongoose.model('Todolist'),
	_ = require('lodash');

/**
 * Create a Todolist
 */
exports.create = function(req, res) {
	var todolist = new Todolist(req.body);
	todolist.user = req.user;

	todolist.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(todolist);
		}
	});
};

/**
 * Show the current Todolist
 */
exports.read = function(req, res) {
	res.jsonp(req.todolist);
};

/**
 * Update a Todolist
 */
exports.update = function(req, res) {
	var todolist = req.todolist ;

	todolist = _.extend(todolist , req.body);

	todolist.save(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(todolist);
		}
	});
};

/**
 * Delete an Todolist
 */
exports.delete = function(req, res) {
	var todolist = req.todolist ;

	todolist.remove(function(err) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(todolist);
		}
	});
};

/**
 * List of Todolists
 */
exports.list = function(req, res) { Todolist.find().sort('-created').populate('user', 'displayName').exec(function(err, todolists) {
		if (err) {
			return res.status(400).send({
				message: errorHandler.getErrorMessage(err)
			});
		} else {
			res.jsonp(todolists);
		}
	});
};

/**
 * Todolist middleware
 */
exports.todolistByID = function(req, res, next, id) { Todolist.findById(id).populate('user', 'displayName').exec(function(err, todolist) {
		if (err) return next(err);
		if (! todolist) return next(new Error('Failed to load Todolist ' + id));
		req.todolist = todolist ;
		next();
	});
};

/**
 * Todolist authorization middleware
 */
exports.hasAuthorization = function(req, res, next) {
	if (req.todolist.user.id !== req.user.id) {
		return res.status(403).send('User is not authorized');
	}
	next();
};