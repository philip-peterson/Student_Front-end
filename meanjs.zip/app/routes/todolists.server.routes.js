'use strict';

module.exports = function(app) {
	var users = require('../../app/controllers/users');
	var todolists = require('../../app/controllers/todolists');

	// Todolists Routes
	app.route('/todolists')
		.get(todolists.list)
		.post(users.requiresLogin, todolists.create);

	app.route('/todolists/:todolistId')
		.get(todolists.read)
		.put(users.requiresLogin, todolists.hasAuthorization, todolists.update)
		.delete(users.requiresLogin, todolists.hasAuthorization, todolists.delete);

	// Finish by binding the Todolist middleware
	app.param('todolistId', todolists.todolistByID);
};