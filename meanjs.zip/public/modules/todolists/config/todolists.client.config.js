'use strict';

// Configuring the Articles module
angular.module('todolists').run(['Menus',
	function(Menus) {
		// Set top bar menu items
		Menus.addMenuItem('topbar', 'Todo-list', 'todolists');
		Menus.addSubMenuItem('topbar', 'todolists', 'List Todolist', 'todolists');
	}
]);