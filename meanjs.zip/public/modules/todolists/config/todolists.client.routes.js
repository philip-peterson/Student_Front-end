'use strict';

//Setting up route
angular.module('todolists').config(['$stateProvider',
	function($stateProvider) {
		// Todolists state routing
		$stateProvider.
		state('listTodolists', {
			url: '/todolists',
			templateUrl: 'modules/todolists/views/list-todolists.client.view.html'
		}).
		state('createTodolist', {
			url: '/todolists/create',
			templateUrl: 'modules/todolists/views/create-todolist.client.view.html'
		}).
		state('viewTodolist', {
			url: '/todolists/:todolistId',
			templateUrl: 'modules/todolists/views/view-todolist.client.view.html'
		}).
		state('editTodolist', {
			url: '/todolists/:todolistId/edit',
			templateUrl: 'modules/todolists/views/edit-todolist.client.view.html'
		});
	}
]);