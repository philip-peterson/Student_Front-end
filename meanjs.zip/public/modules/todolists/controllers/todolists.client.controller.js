'use strict';

// Todolists controller
angular.module('todolists').controller('TodolistsController', ['$scope', '$stateParams', '$location', 'Authentication', 'Todolists',
	function($scope, $stateParams, $location, Authentication, Todolists ) {
		$scope.authentication = Authentication;

		// Create new Todolist
		$scope.create = function() {
			// Create new Todolist object
			var todolist = new Todolists ({
				name: this.name
			});

			// Redirect after save
			todolist.$save(function(response) {
				$location.path('todolists');

				// Clear form fields
				$scope.name = '';
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Remove existing Todolist
		$scope.remove = function( todolist ) {
			if ( todolist ) { todolist.$remove();

				for (var i in $scope.todolists ) {
					if ($scope.todolists [i] === todolist ) {
						$scope.todolists.splice(i, 1);
					}
				}
			} else {
				$scope.todolist.$remove(function() {
					$location.path('todolists');
				});
			}
		};

		// Update existing Todolist
		$scope.update = function() {
			var todolist = $scope.todolist ;

			todolist.$update(function() {
				$location.path('todolists/' + todolist._id);
			}, function(errorResponse) {
				$scope.error = errorResponse.data.message;
			});
		};

		// Find a list of Todolists
		$scope.find = function() {
			$scope.todolists = Todolists.query();
		};

		// Find existing Todolist
		$scope.findOne = function() {
			$scope.todolist = Todolists.get({ 
				todolistId: $stateParams.todolistId
			});
		};
	}
]);