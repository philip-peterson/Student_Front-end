'use strict';

//Todolists service used to communicate Todolists REST endpoints
angular.module('todolists').factory('Todolists', ['$resource',
	function($resource) {
		return $resource('todolists/:todolistId', { todolistId: '@_id'
		}, {
			update: {
				method: 'PUT'
			}
		});
	}
]);